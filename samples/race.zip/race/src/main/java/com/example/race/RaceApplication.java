package com.example.race;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RaceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RaceApplication.class, args);
	}

}
